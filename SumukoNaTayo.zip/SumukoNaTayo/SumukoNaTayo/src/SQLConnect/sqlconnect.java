/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package SQLConnect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Alecz Reyes
 */
public class sqlconnect {
    public static Connection connection;
    
    public static Connection connectSQL() {
        String url = "jdbc:mysql://localhost:3306/dbclinic";
        String user = "root";
        String pass = "";
        
        try {
            connection = DriverManager.getConnection(url, user, pass);
            
            return connection;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Cannot connect to database", "SQL Error", JOptionPane.ERROR_MESSAGE);

            System.exit(0);
        }
        
        return null;
    }
}
