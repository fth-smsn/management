/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package records;

import SQLConnect.sqlconnect;
import java.sql.Connection;

import finance.Billing;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Faith Samson
 */
public class PatientManagementMaster extends javax.swing.JFrame {
    
    Connection connection = sqlconnect.connectSQL();
    
private final DefaultTableModel model;
private int selectedRow = -1;
private final PatientManagementJr parentFrame;
private final String userName;
private final String userRole;

private String pID;
private String tblname = "tbl" + pID + "History"; 

// Variables to store the original values before editing
private String originalLastVisit;
private String originalDiagnosis;
private String originalTreatment;

/**
 * Creates new form PatientManagementMaster
 */

public PatientManagementMaster(PatientManagementJr parentFrame, String username, String role, 
                               String pID, String name, String age, String gender, String status, 
                               String occupation, String contact, String address, String complaint) {
    
    initComponents();
    
    this.pID = pID;
    this.tblname = "tbl" + pID + "History";
    getData();
    
    model = (DefaultTableModel) hTable.getModel(); 
    this.parentFrame = parentFrame;
    this.userName = username;
    this.userRole = role;

    NameLabel.setText("Name: " + name);
    AgeLabel.setText("Age: " + age);
    GenderLabel.setText("Gender: " + gender);
    StatusLabel.setText("Status: " + status);
    OccupationLabel.setText("Occupation: " + occupation);
    ContactNoLabel.setText("Contact No: " + contact);
    AddressLabel.setText("Address: " + address);
    ComplaintLabel.setText("Complaint: " + complaint);
    }

    private void getData() {
            
            String query = "SELECT * FROM " + tblname;

            try {
                PreparedStatement statement = connection.prepareStatement(query);
                ResultSet result = statement.executeQuery();

                DefaultTableModel model = (DefaultTableModel) hTable.getModel();
                model.setRowCount(0);

                while (result.next()) {
                    model.addRow(new Object[] {     
                        result.getString("lastVisit"),
                        result.getString("diagnosis"),
                        result.getString("treatment"),
                        result.getString("creditAmount"),
                        result.getString("balance"),
                    });
                }

            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    
        private void updateDataInDatabase() {
            if (selectedRow < 0) {
                JOptionPane.showMessageDialog(null, "No row selected for update.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Get updated values from text fields
            String newLastVisit = txtLastVisit.getText().trim();
            String newDiagnosis = txtDiagnosis.getText().trim();
            String newTreatment = txtTreatment.getText().trim();
            String newCreditAmount = txtTCreditAmount.getText().trim();
            String newBalance = txtBalance.getText().trim();

            // Validate input fields
            if (newLastVisit.isEmpty() || newDiagnosis.isEmpty() || newTreatment.isEmpty() || newCreditAmount.isEmpty() || newBalance.isEmpty()) {
                JOptionPane.showMessageDialog(null, "All fields must be filled.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                Double.valueOf(newCreditAmount);
                Double.valueOf(newBalance);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Credit Amount and Balance must be valid numbers.", "Validation Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // SQL query to update the row
            String tblname = "tbl" + pID + "History";
            String query = "UPDATE " + tblname + " SET lastVisit = ?, diagnosis = ?, treatment = ?, creditAmount = ?, balance = ? " +
                           "WHERE lastVisit = ? AND diagnosis = ? AND treatment = ?";

            try (PreparedStatement statement = connection.prepareStatement(query)) {
                // Set new values
                statement.setString(1, newLastVisit);
                statement.setString(2, newDiagnosis);
                statement.setString(3, newTreatment);
                statement.setString(4, newCreditAmount);
                statement.setString(5, newBalance);

                // Use original values for WHERE clause
                statement.setString(6, originalLastVisit);
                statement.setString(7, originalDiagnosis);
                statement.setString(8, originalTreatment);

                int rowsAffected = statement.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Patient History Updated", "Database Updated", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "No matching row found to update. Please verify the data.", "Update Failed", JOptionPane.ERROR_MESSAGE);
                }

                getData(); // Refresh the table
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null, "Error updating patient history: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                System.out.println("Error: " + e.getMessage());
            }
        }
        
        // Method to delete patient history from the database
        private void deleteDataFromDatabase() {
            String tblname = "tbl" + pID + "History";
            String query = "DELETE FROM " + tblname + " WHERE lastVisit = ? AND diagnosis = ? AND treatment = ?";

            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, model.getValueAt(selectedRow, 0).toString());
                statement.setString(2, model.getValueAt(selectedRow, 1).toString());
                statement.setString(3, model.getValueAt(selectedRow, 2).toString());

                int rowsAffected = statement.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Patient History Deleted", "Database Updated", JOptionPane.INFORMATION_MESSAGE);
                    model.removeRow(selectedRow);
                }
            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        txtDiagnosis = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        AddressLabel = new javax.swing.JLabel();
        OccupationLabel = new javax.swing.JLabel();
        StatusLabel = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        hTable = new javax.swing.JTable();
        NameLabel = new javax.swing.JLabel();
        txtTreatment = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        ContactNoLabel = new javax.swing.JLabel();
        GenderLabel = new javax.swing.JLabel();
        AgeLabel = new javax.swing.JLabel();
        txtLastVisit = new javax.swing.JTextField();
        ComplaintLabel = new javax.swing.JLabel();
        txtTCreditAmount = new javax.swing.JTextField();
        txtBalance = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        billing = new javax.swing.JButton();
        Save = new javax.swing.JButton();
        Delete = new javax.swing.JButton();
        EDIT = new javax.swing.JButton();
        BackButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(16, 55, 107));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtDiagnosis.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtDiagnosis.setText("Halitosis");
        txtDiagnosis.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDiagnosisActionPerformed(evt);
            }
        });
        jPanel1.add(txtDiagnosis, new org.netbeans.lib.awtextra.AbsoluteConstraints(412, 542, 200, 30));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("LAST VISIT:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 546, -1, -1));

        AddressLabel.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        AddressLabel.setForeground(new java.awt.Color(255, 255, 255));
        AddressLabel.setText("ADDRESS:");
        jPanel1.add(AddressLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 161, -1, -1));

        OccupationLabel.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        OccupationLabel.setForeground(new java.awt.Color(255, 255, 255));
        OccupationLabel.setText("OCCUPATION:");
        jPanel1.add(OccupationLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 80, -1, -1));

        StatusLabel.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        StatusLabel.setForeground(new java.awt.Color(255, 255, 255));
        StatusLabel.setText("STATUS:");
        jPanel1.add(StatusLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 134, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("TREATMENT:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(301, 595, -1, -1));

        hTable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        hTable.setFont(new java.awt.Font("Segoe UI", 0, 14));
        hTable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        hTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "LAST VISIT", "DIAGNOSIS", "TREATMENT", "CREDIT AMOUNT", "BALANCE"
            }
        ));
        hTable.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14)); // Increase font size

        hTable.getTableHeader().setPreferredSize(new java.awt.Dimension(hTable.getWidth(), 30));

        hTable.setRowHeight(30);

        hTable.setSelectionMode(javax.swing.ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        hTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                hTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(hTable);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 196, 952, 334));

        NameLabel.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        NameLabel.setForeground(new java.awt.Color(255, 255, 255));
        NameLabel.setText("NAME:");
        jPanel1.add(NameLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 80, -1, -1));

        txtTreatment.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTreatment.setText("Teeth Cleaning");
        jPanel1.add(txtTreatment, new org.netbeans.lib.awtextra.AbsoluteConstraints(412, 592, 200, 30));

        jLabel10.setFont(new java.awt.Font("Showcard Gothic", 1, 40)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Dental History");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 24, 1000, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("DIAGNOSIS:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(301, 546, -1, -1));

        ContactNoLabel.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        ContactNoLabel.setForeground(new java.awt.Color(255, 255, 255));
        ContactNoLabel.setText("CONTACT NO:");
        jPanel1.add(ContactNoLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 107, -1, -1));

        GenderLabel.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        GenderLabel.setForeground(new java.awt.Color(255, 255, 255));
        GenderLabel.setText("GENDER:");
        jPanel1.add(GenderLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 107, -1, -1));

        AgeLabel.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        AgeLabel.setForeground(new java.awt.Color(255, 255, 255));
        AgeLabel.setText("AGE:");
        jPanel1.add(AgeLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 134, -1, -1));

        txtLastVisit.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtLastVisit.setText("2025-12-25");
        txtLastVisit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtLastVisitActionPerformed(evt);
            }
        });
        jPanel1.add(txtLastVisit, new org.netbeans.lib.awtextra.AbsoluteConstraints(124, 542, 159, 32));

        ComplaintLabel.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        ComplaintLabel.setForeground(new java.awt.Color(255, 255, 255));
        ComplaintLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ComplaintLabel.setText("COMPLAINT:");
        ComplaintLabel.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jPanel1.add(ComplaintLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 161, 477, 23));

        txtTCreditAmount.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtTCreditAmount.setText("500");
        jPanel1.add(txtTCreditAmount, new org.netbeans.lib.awtextra.AbsoluteConstraints(776, 542, 200, 30));

        txtBalance.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtBalance.setText("0");
        jPanel1.add(txtBalance, new org.netbeans.lib.awtextra.AbsoluteConstraints(776, 592, 200, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("CREDIT AMOUNT:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 545, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("BALANCE:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 595, -1, -1));

        jPanel4.setBackground(new java.awt.Color(0, 0, 51));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        billing.setBackground(new java.awt.Color(0, 153, 153));
        billing.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        billing.setForeground(new java.awt.Color(255, 255, 255));
        billing.setText("BILLING");
        billing.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 12), new java.awt.Color(255, 255, 255))); // NOI18N
        billing.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                billingActionPerformed(evt);
            }
        });
        jPanel4.add(billing, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, 190, 35));

        Save.setBackground(new java.awt.Color(0, 153, 0));
        Save.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        Save.setForeground(new java.awt.Color(255, 255, 255));
        Save.setText("SAVE");
        Save.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        Save.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveActionPerformed(evt);
            }
        });
        jPanel4.add(Save, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 6, 190, 35));

        Delete.setBackground(new java.awt.Color(255, 51, 51));
        Delete.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        Delete.setForeground(new java.awt.Color(255, 255, 255));
        Delete.setText("DELETE");
        Delete.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        Delete.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });
        jPanel4.add(Delete, new org.netbeans.lib.awtextra.AbsoluteConstraints(602, 6, 190, 35));

        EDIT.setBackground(new java.awt.Color(102, 102, 102));
        EDIT.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        EDIT.setForeground(new java.awt.Color(255, 255, 255));
        EDIT.setText("EDIT");
        EDIT.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        EDIT.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        EDIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EDITActionPerformed(evt);
            }
        });
        jPanel4.add(EDIT, new org.netbeans.lib.awtextra.AbsoluteConstraints(406, 6, 190, 35));

        BackButton.setBackground(new java.awt.Color(102, 102, 255));
        BackButton.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        BackButton.setForeground(new java.awt.Color(255, 255, 255));
        BackButton.setText("DASHBOARD");
        BackButton.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        BackButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });
        jPanel4.add(BackButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(804, 6, 190, 35));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 640, 1000, 60));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void hTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hTableMouseClicked
        selectedRow = hTable.getSelectedRow();
    }//GEN-LAST:event_hTableMouseClicked

    private void EDITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EDITActionPerformed
        selectedRow = hTable.getSelectedRow();
        if (selectedRow >= 0) {
            // Save the original values before editing
            originalLastVisit = model.getValueAt(selectedRow, 0).toString().trim();
            originalDiagnosis = model.getValueAt(selectedRow, 1).toString().trim();
            originalTreatment = model.getValueAt(selectedRow, 2).toString().trim();

            // Populate the text fields with the selected row's data
            txtLastVisit.setText(originalLastVisit);
            txtDiagnosis.setText(originalDiagnosis);
            txtTreatment.setText(originalTreatment);
            txtTCreditAmount.setText(model.getValueAt(selectedRow, 3).toString().trim());
            txtBalance.setText(model.getValueAt(selectedRow, 4).toString().trim());
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to edit.");
        }
    }//GEN-LAST:event_EDITActionPerformed

    private void SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveActionPerformed
        // Error handling for the Last Visit date format
        String lastVisit = txtLastVisit.getText().trim();
        if (!lastVisit.matches("^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$")) {
            JOptionPane.showMessageDialog(null, "Date must be in the format YYYY-MM-DD", "Invalid Date Format", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Error handling for the Credit Amount and Balance to ensure they are numbers
        String creditAmount = txtTCreditAmount.getText().trim();
        String balance = txtBalance.getText().trim();
        try {
            Double.valueOf(creditAmount);
            Double.valueOf(balance);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Credit Amount and Balance must be numbers", "Invalid Number Format", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Error handling to ensure all fields are filled
        String diagnosis = txtDiagnosis.getText().trim();
        String treatment = txtTreatment.getText().trim();
        if (lastVisit.isEmpty() || diagnosis.isEmpty() || treatment.isEmpty() || creditAmount.isEmpty() || balance.isEmpty()) {
            JOptionPane.showMessageDialog(null, "All fields must be filled", "Empty Fields", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (selectedRow >= 0) {
            // Update existing row in the JTable
            model.setValueAt(lastVisit, selectedRow, 0);
            model.setValueAt(diagnosis, selectedRow, 1);
            model.setValueAt(treatment, selectedRow, 2);
            model.setValueAt(creditAmount, selectedRow, 3);
            model.setValueAt(balance, selectedRow, 4);

            // Update the database
            updateDataInDatabase();

            selectedRow = -1; // Reset selection after update
        } else {
            // Add new row to JTable
            Object[] newRow = {
                lastVisit,
                diagnosis,
                treatment,
                creditAmount,
                balance
            };

            model.addRow(newRow);

            String tblname = "tbl" + pID + "History";
            String query = "INSERT INTO " + tblname + " (lastVisit, diagnosis, treatment, creditAmount, balance) VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, lastVisit);
                statement.setString(2, diagnosis);
                statement.setString(3, treatment);
                statement.setString(4, creditAmount);
                statement.setString(5, balance);

                int rowsAffected = statement.executeUpdate();
                if (rowsAffected > 0) {
                    JOptionPane.showMessageDialog(null, "Patient History Added", "Database Updated", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        getData();
        clearFields();
    }//GEN-LAST:event_SaveActionPerformed

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
    // Delete selected row from the JTable and the database
        int selectedRow = hTable.getSelectedRow();
        if (selectedRow != -1) {
            deleteDataFromDatabase();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.");
        }
    }//GEN-LAST:event_DeleteActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        // TODO add your handling code here:
        this.dispose(); 
        Dashboard dashboard = new Dashboard(userName, userRole);
        dashboard.setVisible(true);


    }//GEN-LAST:event_BackButtonActionPerformed

    private void billingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_billingActionPerformed
        // Check if at least one row is selected
        int[] selectedRows = hTable.getSelectedRows();
        if (selectedRows.length > 0) {
            // Get data from the selected rows
            String name = NameLabel.getText().replace("Name: ", "");
            String address = AddressLabel.getText().replace("Address: ", "");
            String contact = ContactNoLabel.getText().replace("Contact No: ", "");

            // Open the Billing form with the selected patient data
            Billing billingForm = new Billing(userName, userRole);
            billingForm.setPatientData(name, address, contact);

            // Add selected rows to the Billing table
            DefaultTableModel billingModel = (DefaultTableModel) billingForm.getbTable().getModel();
            for (int row : selectedRows) {
                Object[] rowData = {
                    model.getValueAt(row, 2), // lastVisit
                    model.getValueAt(row, 3)  // creditAmount
                };
                billingModel.addRow(rowData);
            }

            billingForm.setVisible(true);
            this.setVisible(false); 
        } else {
            JOptionPane.showMessageDialog(this, "Please select at least one row to proceed with billing.");
        }
    }//GEN-LAST:event_billingActionPerformed

    private void txtLastVisitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtLastVisitActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtLastVisitActionPerformed

    private void txtDiagnosisActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDiagnosisActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDiagnosisActionPerformed

    /**
     * @param args the command line arguments
     */
    private void clearFields() {
        txtLastVisit.setText("");
        txtDiagnosis.setText("");
        txtTreatment.setText("");
        txtTCreditAmount.setText("");
        txtBalance.setText("");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PatientManagementMaster.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
   
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AddressLabel;
    private javax.swing.JLabel AgeLabel;
    private javax.swing.JButton BackButton;
    private javax.swing.JLabel ComplaintLabel;
    private javax.swing.JLabel ContactNoLabel;
    private javax.swing.JButton Delete;
    private javax.swing.JButton EDIT;
    private javax.swing.JLabel GenderLabel;
    private javax.swing.JLabel NameLabel;
    private javax.swing.JLabel OccupationLabel;
    private javax.swing.JButton Save;
    private javax.swing.JLabel StatusLabel;
    private javax.swing.JButton billing;
    private javax.swing.JTable hTable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtBalance;
    private javax.swing.JTextField txtDiagnosis;
    private javax.swing.JTextField txtLastVisit;
    private javax.swing.JTextField txtTCreditAmount;
    private javax.swing.JTextField txtTreatment;
    // End of variables declaration//GEN-END:variables
}
