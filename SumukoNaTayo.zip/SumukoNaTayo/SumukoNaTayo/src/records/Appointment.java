/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package records;

/**
 *
 * @author Faith Samson
 */

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JOptionPane;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import SQLConnect.sqlconnect;
import java.util.Arrays;
import javax.swing.RowSorter;
import javax.swing.SortOrder;

import util.*;

public class Appointment extends javax.swing.JFrame {

    Connection connection = sqlconnect.connectSQL();
    
    private static int patientID = 0001;
    
    private String getCurrentDate() {
        SimpleDateFormat formatter = new SimpleDateFormat("MM-dd-yyyy");
        return formatter.format(new Date());
    }
    
    //  for generating patient ID      
    private String appointmentID() {
        return String.format("AS-%05d", patientID++);
    }
    
    private String patientID() {
        return String.format("PR-%05d", patientID++);
    }
    
    private void getData() {
        String query = "SELECT * FROM tblappointment";

        try {
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet result = statement.executeQuery();

            DefaultTableModel model = (DefaultTableModel) pTable.getModel();
            model.setRowCount(0);

            while (result.next()) {
                model.addRow(new Object[] {     
                    result.getString("appointmentID"),
                    result.getString("patientID"),
                    result.getString("name"),
                    result.getString("contactNumber"),
                    result.getString("scheduledDate"),
                    result.getString("scheduledTime"),
                    result.getString("dateCreated"),
                });
            }

            sortTableByScheduledDate(); // Sort the table after fetching data

        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
    
    private void sortTableByScheduledDate() {
        DefaultTableModel model = (DefaultTableModel) pTable.getModel();
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        pTable.setRowSorter(sorter);

        // Sort by the scheduled date column (5th column, index 4) and then by the scheduled time column (6th column, index 5)
        sorter.setComparator(4, (date1, date2) -> {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            try {
                Date d1 = dateFormat.parse(date1.toString());
                Date d2 = dateFormat.parse(date2.toString());
                return d1.compareTo(d2);
            } catch (Exception e) {
                return 0;
            }
        });

        sorter.setComparator(5, (time1, time2) -> {
            SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
            try {
                Date t1 = timeFormat.parse(time1.toString());
                Date t2 = timeFormat.parse(time2.toString());
                return t1.compareTo(t2);
            } catch (Exception e) {
                return 0;
            }
        });

        sorter.setSortKeys(Arrays.asList(
            new RowSorter.SortKey(4, SortOrder.ASCENDING),
            new RowSorter.SortKey(5, SortOrder.ASCENDING)
        ));
        sorter.sort();
    }
    
    private String[] getSelectedRowData() {
        int selectedRow = pTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select an appointment first.");
            return null;
        }

        selectedRow = pTable.convertRowIndexToModel(selectedRow); // Convert to model index

        DefaultTableModel model = (DefaultTableModel) pTable.getModel();
        String appointmentID = model.getValueAt(selectedRow, 0).toString();
        String patientID = model.getValueAt(selectedRow, 1).toString();
        String name = model.getValueAt(selectedRow, 2).toString();
        String contactNumber = model.getValueAt(selectedRow, 3).toString();
        String scheduledDate = model.getValueAt(selectedRow, 4).toString();
        String scheduledTime = model.getValueAt(selectedRow, 5).toString();

        return new String[]{appointmentID, patientID, name, contactNumber, scheduledDate, scheduledTime};
    }
    
    // Error handling for contact number
    private boolean isValidContactNumber(String contactNumber) {
        if (!contactNumber.matches("^\\d{11}$")) {
            JOptionPane.showMessageDialog(this, "Invalid contact number. Must be 11 digits.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (!contactNumber.startsWith("09")) {
            JOptionPane.showMessageDialog(this, "Invalid contact number. Must start with '09'.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private boolean isValidScheduledDate(String date) {
        return date.matches("^\\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])$");
    }

    // Error handling for scheduled time in the format H:MM am/pm or HH:MM am/pm
    private boolean isValidScheduledTime(String time) {
        if (!time.matches("^(0?[1-9]|1[0-2]):([0-5][0-9])\\s?(AM|am|PM|pm)$")) {
            JOptionPane.showMessageDialog(this, "Invalid scheduled time format. Use HH:MM am/pm format.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        String[] timeParts = time.split("[:\\s]");
        int hour = Integer.parseInt(timeParts[0]);
        String amPm = timeParts[2].toLowerCase();
        if (amPm.equals("am")) {
            if (hour < 8) {
                JOptionPane.showMessageDialog(this, "Scheduled time must be between 8 am and 5 pm.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } else if (amPm.equals("pm")) {
            if (hour > 5 && hour != 12) {
                JOptionPane.showMessageDialog(this, "Scheduled time must be between 8 am and 5 pm.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        return true;
    }

    // Check if the scheduled date and time are unique
    private boolean isUniqueScheduledDateTime(String date, String time) {
        String query = "SELECT COUNT(*) FROM tblappointment WHERE scheduledDate = ? AND scheduledTime = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, date);
            statement.setString(2, time);
            ResultSet result = statement.executeQuery();
            if (result.next()) {
                return result.getInt(1) == 0;
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
        return false;
    }

    // Method to handle non-unique scheduled date and time
    private void handleNonUniqueScheduledDateTime() {
        JOptionPane.showMessageDialog(this, "The scheduled date and time already exist. Please choose another time.", "Input Error", JOptionPane.ERROR_MESSAGE);
    }
    
    
    
    private void isPatientNew(String name, String pID) {
        String query = "SELECT name FROM tblpatientID WHERE name = '" + name + "'";
        String tblname;
        
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            ResultSet result = statement.executeQuery();
            
            if (!result.isBeforeFirst()) {
                result.next();
                tblname = "tbl" + pID + "History";
                query = "CREATE TABLE " + tblname + "(lastVisit DATE, diagnosis VARCHAR(255), treatment VARCHAR(255), creditAmount DECIMAL(65), balance DECIMAL(65))";
                statement = connection.prepareStatement(query);
                statement.execute();
            }
            
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
             
    }
    
    
    
    // for adding patient appointment
    private void addSched() {
        String aID = appointmentID();
        String pID = IDGenerator.generateID();
        String name = pName.getText().trim();
        String contact = pContact.getText().trim();
        String date = pDate.getText().trim();
        String time = pTime.getText().trim();
        String currentDate = getCurrentDate();

        // Validate contact number
        if (!isValidContactNumber(contact)) {
            return; // Exit the method if contact number is invalid
        }

        // Validate scheduled date
        if (!isValidScheduledDate(date)) {
            JOptionPane.showMessageDialog(this, "Invalid scheduled date. Use YYYY-MM-DD format.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate scheduled time
        if (!isValidScheduledTime(time)) {
            return;
        }

        // Check if the scheduled date and time are unique
        if (!isUniqueScheduledDateTime(date, time)) {
            handleNonUniqueScheduledDateTime();
            return;
        }

        PreparedStatement statement;
        String query;
        boolean found = false;
        int rowsAffected;

        isPatientNew(name, pID);
        
        try {
            query = "SELECT * FROM tblpatientid";
            statement = connection.prepareStatement(query);
            ResultSet result = statement.executeQuery();

            while (result.next()) {
                String reference = result.getString("name");
                if (name.equalsIgnoreCase(reference)) {
                    pID = result.getString("patientID");
                    found = true;
                    break;
                }
            }

            if (!found) {
                query = "INSERT INTO tblpatientid(patientID, name) VALUES (?, ?)";
                statement = connection.prepareStatement(query);
                statement.setString(1, pID);
                statement.setString(2, name);
                rowsAffected = statement.executeUpdate();
                statement.close();
            }
        } catch (SQLException e) {
            System.out.println("Error" + e.getMessage());
        }

        if (!name.isEmpty() && !contact.isEmpty() && !date.isEmpty() && !time.isEmpty()) {
            query = "INSERT INTO tblappointment (patientID, name, contactNumber, scheduledDate, scheduledTime) VALUES (?, ?, ?, ?, ?)";

            try {
                statement = connection.prepareStatement(query);
                statement.setString(1, pID);
                statement.setString(2, name);
                statement.setString(3, contact);
                statement.setString(4, date);
                statement.setString(5, time);
                rowsAffected = statement.executeUpdate();

                if (rowsAffected > 0 && statement != null) {
                    JOptionPane.showMessageDialog(null, "Appointment Added", "Database Updated", JOptionPane.INFORMATION_MESSAGE);
                }

                getData();
                sortTableByScheduledDate();

            } catch (SQLException e) {
                System.out.println("Error" + e.getMessage());
            }

            pName.setText("");
            pContact.setText("");
            pDate.setText("");
            pTime.setText("");
        }
    }
    
    //  for clearing inputs 
    private void clearSched(){
        pSearch.setText("");
        pName.setText("");
        pContact.setText("");
        pDate.setText("");
        pTime.setText("");
        searchPatient();
    }

    // for searching patient name    
    private void searchPatient() {
        String searchText = pSearch.getText().trim().toLowerCase();
        DefaultTableModel model = (DefaultTableModel) pTable.getModel();
        TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
        pTable.setRowSorter(sorter);


        if (searchText.isEmpty()) {
            sorter.setRowFilter(null);
        } else {
            sorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText, 2, 4));
        }

        model.fireTableDataChanged();
    }

    
    // for deleting certain patient appointment
    private void delSched(){
        DefaultTableModel model = (DefaultTableModel) pTable.getModel();
    int selectedRow = pTable.getSelectedRow();

    if (selectedRow != -1) {
        String appointmentID = (String) model.getValueAt(selectedRow, 0);
        
        String query = "DELETE FROM tblappointment WHERE appointmentID = ?";
        
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, appointmentID);
            
            int rowsAffected = statement.executeUpdate();
            
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Appointment Deleted", "Database Updated", JOptionPane.INFORMATION_MESSAGE);
                model.removeRow(selectedRow);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to Delete Appointment", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    } else {
        JOptionPane.showMessageDialog(null, "No Appointment Selected", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    // for deleting certain patient appointment
    private void fenishSched(){
        DefaultTableModel model = (DefaultTableModel) pTable.getModel();
    int selectedRow = pTable.getSelectedRow();

    if (selectedRow != -1) {
        String appointmentID = (String) model.getValueAt(selectedRow, 0);
        
        String query = "DELETE FROM tblappointment WHERE appointmentID = ?";
        
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, appointmentID);
            
            int rowsAffected = statement.executeUpdate();
            
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Appointment Finished", "Database Updated", JOptionPane.INFORMATION_MESSAGE);
                model.removeRow(selectedRow);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to Delete Appointment", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }
    } else {
        JOptionPane.showMessageDialog(null, "No Appointment Selected", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
private final String userName;
private final String userRole;

public Appointment(String username, String role) {
    initComponents();
    
    getData();
    
    this.userName = username;
    this.userRole = role;
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        pTime = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        FinishApp = new javax.swing.JButton();
        pContact = new javax.swing.JTextField();
        dashBoard = new javax.swing.JButton();
        pSearch = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        pTable = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        searchBTN = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        pDate = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        delSched = new javax.swing.JButton();
        addSched = new javax.swing.JButton();
        pName = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(16, 55, 107));

        pTime.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        pTime.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pTime.setText("12:00 am");
        pTime.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        pTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pTimejTextField3ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("CONTACT NUMBER:");
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("SCHEDULED DATE:");
        jLabel9.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("PATIENT NAME:");
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        FinishApp.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        FinishApp.setText("FINISH APPOINTMENT");
        FinishApp.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        FinishApp.setBorderPainted(false);
        FinishApp.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        FinishApp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FinishAppActionPerformed(evt);
            }
        });

        pContact.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        pContact.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pContact.setText("09123456789");
        pContact.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        pContact.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pContactjTextField3ActionPerformed(evt);
            }
        });

        dashBoard.setBackground(new java.awt.Color(102, 102, 255));
        dashBoard.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        dashBoard.setForeground(new java.awt.Color(255, 255, 255));
        dashBoard.setText("DASHBOARD");
        dashBoard.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        dashBoard.setBorderPainted(false);
        dashBoard.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        dashBoard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dashBoardActionPerformed(evt);
            }
        });

        pSearch.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        pSearch.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pSearch.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        pSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pSearchjTextField3ActionPerformed(evt);
            }
        });

        pTable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        pTable.setFont(new java.awt.Font("Segoe UI", 0, 14));
        pTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "APPOINTMENT ID", "PATIENT ID", "PATIENT NAME", "CONTACT", "SCHEDULED DATE", "SCHEDULED TIME", "CURRENT DATE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, true, true, true, true, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        pTable.setAlignmentX(1.0F);
        pTable.setAlignmentY(1.0F);
        pTable.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14)); // Increase font size
        pTable.getTableHeader().setPreferredSize(new java.awt.Dimension(pTable.getWidth(), 30));
        pTable.setRowHeight(30);
        pTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                pTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(pTable);
        pTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        if (pTable.getColumnModel().getColumnCount() > 0) {
            pTable.getColumnModel().getColumn(0).setResizable(false);
            pTable.getColumnModel().getColumn(0).setPreferredWidth(100);
            pTable.getColumnModel().getColumn(1).setPreferredWidth(80);
            pTable.getColumnModel().getColumn(2).setPreferredWidth(100);
            pTable.getColumnModel().getColumn(3).setPreferredWidth(60);
            pTable.getColumnModel().getColumn(4).setPreferredWidth(90);
            pTable.getColumnModel().getColumn(5).setPreferredWidth(80);
            pTable.getColumnModel().getColumn(6).setPreferredWidth(80);
        }

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("SEARCH PATIENT NAME/DATE:");
        jLabel5.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        searchBTN.setBackground(new java.awt.Color(204, 204, 204));
        searchBTN.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        searchBTN.setText("SEARCH");
        searchBTN.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        searchBTN.setBorderPainted(false);
        searchBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        searchBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBTNActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("SCHEDULED TIME:");
        jLabel7.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        pDate.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        pDate.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pDate.setText("2025-12-25");
        pDate.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        pDate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pDatejTextField3ActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Showcard Gothic", 1, 40)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Schedule Appointment");
        jLabel4.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel4.setDoubleBuffered(true);

        delSched.setBackground(new java.awt.Color(255, 51, 51));
        delSched.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        delSched.setForeground(new java.awt.Color(255, 255, 255));
        delSched.setText("DELETE");
        delSched.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        delSched.setBorderPainted(false);
        delSched.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        delSched.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delSchedActionPerformed(evt);
            }
        });

        addSched.setBackground(new java.awt.Color(0, 153, 0));
        addSched.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        addSched.setForeground(new java.awt.Color(255, 255, 255));
        addSched.setText("ADD SCHEDULE");
        addSched.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        addSched.setBorderPainted(false);
        addSched.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        addSched.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addSchedActionPerformed(evt);
            }
        });

        pName.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        pName.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pName.setText("Doctor Quack");
        pName.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        pName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pNamejTextField3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(33, 33, 33)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(pDate, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(pName, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(pContact, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(pTime, javax.swing.GroupLayout.PREFERRED_SIZE, 351, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(67, 67, 67)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(addSched, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(FinishApp, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(dashBoard, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(delSched, javax.swing.GroupLayout.PREFERRED_SIZE, 280, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 950, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(65, 65, 65)
                        .addComponent(jLabel5)
                        .addGap(28, 28, 28)
                        .addComponent(pSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(searchBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 336, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(pName, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(pContact, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(pDate, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(pTime, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(FinishApp, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(addSched, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(delSched, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dashBoard, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(31, 31, 31))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {dashBoard, searchBTN});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void pSearchjTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pSearchjTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pSearchjTextField3ActionPerformed

    private void pContactjTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pContactjTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pContactjTextField3ActionPerformed

    private void searchBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBTNActionPerformed
        // TODO add your handling code here:
        searchPatient();
    }//GEN-LAST:event_searchBTNActionPerformed

    private void pTimejTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pTimejTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pTimejTextField3ActionPerformed

    private void FinishAppActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FinishAppActionPerformed
         String[] rowData = getSelectedRowData();
    if (rowData != null) {
        // Delete the appointment
        fenishSched();

        // Check if patient exists in the patient management database
        boolean patientExists = false;
        String query = "SELECT * FROM tblpatientinfo WHERE patientID = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, rowData[1]);
            ResultSet result = statement.executeQuery();
            if (result.next()) {
                patientExists = true;
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Redirect to PatientManagementJr with the rowData
        this.dispose();
        PatientManagementJr patientManagement = new PatientManagementJr(userName, userRole, rowData, patientExists);
        patientManagement.setVisible(true);
        }
    }//GEN-LAST:event_FinishAppActionPerformed

    private void delSchedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delSchedActionPerformed
        // TODO add your handling code here:
            delSched();
    }//GEN-LAST:event_delSchedActionPerformed

    private void dashBoardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashBoardActionPerformed
        // TODO add your handling code here:
        this.dispose();
        Dashboard dashboard = new Dashboard(userName, userRole); // Pass the correct values
        dashboard.setVisible(true);
    }//GEN-LAST:event_dashBoardActionPerformed

    private void addSchedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addSchedActionPerformed
        // TODO add your handling code here:
            addSched();
    }//GEN-LAST:event_addSchedActionPerformed

    private void pNamejTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pNamejTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pNamejTextField3ActionPerformed

    private void pDatejTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pDatejTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pDatejTextField3ActionPerformed

    private void pTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_pTableMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_pTableMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
    //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
    /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
     * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
     */
    try {
        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("Nimbus".equals(info.getName())) {
                javax.swing.UIManager.setLookAndFeel(info.getClassName());
                break;
            }
        }
    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
        java.util.logging.Logger.getLogger(Appointment.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }
        //</editor-fold>
        
    //</editor-fold>

    /* Create and display the form */
    java.awt.EventQueue.invokeLater(() -> {
    });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton FinishApp;
    private javax.swing.JButton addSched;
    private javax.swing.JButton dashBoard;
    private javax.swing.JButton delSched;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField pContact;
    private javax.swing.JTextField pDate;
    private javax.swing.JTextField pName;
    private javax.swing.JTextField pSearch;
    private javax.swing.JTable pTable;
    private javax.swing.JTextField pTime;
    private javax.swing.JButton searchBTN;
    // End of variables declaration//GEN-END:variables
}
