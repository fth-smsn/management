/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import static SQLConnect.sqlconnect.connection;
import java.time.Year;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Alecz Reyes
 */
public class IDGenerator {
    public static String generateID() {
    
    String addZero, UID, query;
        int id = 0;
        int year = Year.now().getValue();

        query = "SELECT * FROM tblpatientid ORDER BY ID DESC LIMIT 1";

        try {
            PreparedStatement statement = connection.prepareStatement(query);

            ResultSet result = statement.executeQuery();

            if  (result.next()) {
                id = Integer.parseInt(result.getString("ID")) + 1;
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Cannot generate ID", "Sql Error", JOptionPane.ERROR_MESSAGE);
        }

        if (id > 999) {
            addZero = "";
        } else if (id > 99) {
            addZero = "0";
        } else if (id > 9) {
            addZero = "00";
        } else {
            addZero = "000";
        }

        UID = "PA" + year + "_" + addZero + id;
        
        return UID;

    }
}
