/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package records;

import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import SQLConnect.sqlconnect;
import util.IDGenerator;

import javax.swing.RowFilter;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author Faith Samson
 */
public final class PatientManagementJr extends javax.swing.JFrame {

    
    Connection connection = sqlconnect.connectSQL();
    
    private final DefaultTableModel model;
    private int selectedRow = -1;
    private final ButtonGroup genderGroup; 

    /**
     * Creates new form PatientManagementJr
     */
    
    
        
    private void goToDashboard() {
    this.dispose(); // Close current window
    Dashboard dashboard = new Dashboard(userName, userRole); // Pass values
    dashboard.setVisible(true);
}
    
    
    
    private final String userName;
    private final String userRole;

    public PatientManagementJr(String username, String role) {
        initComponents();

        this.userName = username;
        this.userRole = role;

        model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Patient ID");
        model.addColumn("Name");
        model.addColumn("Age");
        model.addColumn("Gender");
        model.addColumn("Status");
        model.addColumn("Occupation");
        model.addColumn("Contact No.");
        model.addColumn("Address");
        model.addColumn("Complaint");
        jTable1.setModel(model);

        genderGroup = new ButtonGroup();
        genderGroup.add(Male);
        genderGroup.add(Female);

        getData();
    }
    
    public PatientManagementJr(String username, String role, String[] appointmentData, boolean patientExists) {
        this(username, role);

        if (appointmentData != null) {
            Name.setText(appointmentData[2]);
            ContactNo.setText(appointmentData[3]);
            if (patientExists) {
                // Prefill other fields with existing patient data
                try {
                    String query = "SELECT * FROM tblpatientinfo WHERE patientID = ?";
                    PreparedStatement statement = connection.prepareStatement(query);
                    statement.setString(1, appointmentData[1]);
                    ResultSet result = statement.executeQuery();
                    if (result.next()) {
                        Age.setValue(Integer.valueOf(result.getString("age")));
                        if ("Male".equalsIgnoreCase(result.getString("gender"))) {
                            Male.setSelected(true);
                        } else {
                            Female.setSelected(true);
                        }
                        jComboBox1.setSelectedItem(result.getString("maritalStatus"));
                        Occupation.setText(result.getString("occupation"));
                        Address.setText(result.getString("address"));
                        Complaint.setText(result.getString("complaint"));
                    }
                } catch (SQLException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        }
    }
    
    // Method to validate contact number
    private boolean isValidContactNumber(String contactNumber) {
        if (!contactNumber.matches("^\\d{11}$")) {
            JOptionPane.showMessageDialog(this, "Invalid contact number. Must be 11 digits.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (!contactNumber.startsWith("09")) {
            JOptionPane.showMessageDialog(this, "Invalid contact number. Must start with '09'.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    // Method to validate all fields
    private boolean areFieldsFilled(String name, String age, String gender, String maritalStatus, String occupation, String contactNumber, String address, String complaint) {
        return !name.isEmpty() && !age.isEmpty() && !gender.isEmpty() && !maritalStatus.isEmpty() && !occupation.isEmpty() && !contactNumber.isEmpty() && !address.isEmpty() && !complaint.isEmpty();
    }
     
    private void getData() {
    String query = "SELECT * FROM tblpatientinfo";

    try (PreparedStatement statement = connection.prepareStatement(query)) {
        ResultSet resultSet = statement.executeQuery();
        
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.setRowCount(0); // Clear existing rows

        while (resultSet.next()) {
            model.addRow(new Object[] {
                resultSet.getString("ID"),
                resultSet.getString("patientID"),
                resultSet.getString("name"),
                resultSet.getString("age"),
                resultSet.getString("gender"),
                resultSet.getString("maritalStatus"),
                resultSet.getString("occupation"),
                resultSet.getString("contactNumber"),
                resultSet.getString("address"),
                resultSet.getString("complaint")
            });
        }
    } catch (SQLException e) {
        System.out.println("Error: " + e.getMessage());
        JOptionPane.showMessageDialog(this, "Error fetching data: " + e.getMessage());
        }
    }
    
    // Method to delete data from the database
    private void deleteDataFromDatabase(int id, String patientID) {
        String deletePatientInfoSql = "DELETE FROM tblpatientinfo WHERE id = ?";
        String deletePatientIDSql = "DELETE FROM tblpatientid WHERE patientID = ?";
        try (PreparedStatement deletePatientInfoStmt = connection.prepareStatement(deletePatientInfoSql);
             PreparedStatement deletePatientIDStmt = connection.prepareStatement(deletePatientIDSql)) {

            // Delete from tblpatientinfo
            deletePatientInfoStmt.setInt(1, id);
            deletePatientInfoStmt.executeUpdate();

            // Delete from tblpatientid
            deletePatientIDStmt.setString(1, patientID);
            deletePatientIDStmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data deleted successfully!");

            // Drop the patient's history table
            String historyTable = "tbl" + patientID + "History";
            String dropTableSql = "DROP TABLE IF EXISTS " + historyTable;
            try (PreparedStatement dropStmt = connection.prepareStatement(dropTableSql)) {
                dropStmt.executeUpdate();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error dropping history table: " + e.getMessage());
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error deleting data: " + e.getMessage());
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        Save = new javax.swing.JButton();
        Address = new javax.swing.JTextField();
        Age = new javax.swing.JSpinner();
        jScrollPane2 = new javax.swing.JScrollPane();
        Complaint = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        Female = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        Occupation = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        ContactNo = new javax.swing.JTextField();
        Edit = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        Register = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        Name = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        Delete = new javax.swing.JButton();
        Male = new javax.swing.JRadioButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        dashBoard = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        searchBTN = new javax.swing.JButton();
        pSearch = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(16, 55, 107));

        Save.setBackground(new java.awt.Color(0, 153, 0));
        Save.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        Save.setForeground(new java.awt.Color(255, 255, 255));
        Save.setText("SAVE ");
        Save.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Save.setBorderPainted(false);
        Save.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SaveActionPerformed(evt);
            }
        });

        Address.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AddressActionPerformed(evt);
            }
        });

        Age.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));

        Complaint.setColumns(20);
        Complaint.setRows(5);
        jScrollPane2.setViewportView(Complaint);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("OCCUPATION:");

        jLabel1.setFont(new java.awt.Font("Showcard Gothic", 1, 40)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Patient Management");

        Female.setBackground(new java.awt.Color(16, 55, 107));
        Female.setForeground(new java.awt.Color(255, 255, 255));
        Female.setText("FEMALE");
        Female.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FemaleActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("NAME:");

        Occupation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OccupationActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("GENDER:");

        ContactNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContactNoActionPerformed(evt);
            }
        });

        Edit.setBackground(new java.awt.Color(102, 102, 102));
        Edit.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        Edit.setForeground(new java.awt.Color(255, 255, 255));
        Edit.setText("EDIT");
        Edit.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Edit.setBorderPainted(false);
        Edit.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EditActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("ADDRESS:");

        Register.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        Register.setText("REGISTER");
        Register.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Register.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Register.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("STATUS:");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("CONTACT NO:");

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("AGE:");

        Name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                NameActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("COMPLAINT:");

        Delete.setBackground(new java.awt.Color(255, 51, 51));
        Delete.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        Delete.setForeground(new java.awt.Color(255, 255, 255));
        Delete.setText("DELETE");
        Delete.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        Delete.setBorderPainted(false);
        Delete.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteActionPerformed(evt);
            }
        });

        Male.setBackground(new java.awt.Color(16, 55, 107));
        Male.setForeground(new java.awt.Color(255, 255, 255));
        Male.setText("MALE");
        Male.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MaleActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID", "Patient ID", "Name", "Age", "Gender", "Status", "Occupation", "Contact No.", "Address", "Complaint"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14)); // Increase font size
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setPreferredWidth(50);
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setResizable(false);
            jTable1.getColumnModel().getColumn(6).setResizable(false);
            jTable1.getColumnModel().getColumn(7).setResizable(false);
            jTable1.getColumnModel().getColumn(8).setResizable(false);
            jTable1.getColumnModel().getColumn(9).setResizable(false);
        }

        dashBoard.setBackground(new java.awt.Color(102, 102, 255));
        dashBoard.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        dashBoard.setForeground(new java.awt.Color(255, 255, 255));
        dashBoard.setText("DASHBOARD");
        dashBoard.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        dashBoard.setBorderPainted(false);
        dashBoard.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        dashBoard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dashBoardActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 15)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("SEARCH PATIENT NAME:");
        jLabel10.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));

        searchBTN.setBackground(new java.awt.Color(204, 204, 204));
        searchBTN.setFont(new java.awt.Font("Lucida Sans Typewriter", 1, 15)); // NOI18N
        searchBTN.setText("SEARCH");
        searchBTN.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        searchBTN.setBorderPainted(false);
        searchBTN.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        searchBTN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBTNActionPerformed(evt);
            }
        });

        pSearch.setFont(new java.awt.Font("Segoe UI", 0, 15)); // NOI18N
        pSearch.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        pSearch.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        pSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pSearchjTextField3ActionPerformed(evt);
            }
        });

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Single", "Married", "Separated", "Divorced", "Widowed" }));
        jComboBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(265, 265, 265)
                .addComponent(jLabel1))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(85, 85, 85)
                .addComponent(jLabel10)
                .addGap(28, 28, 28)
                .addComponent(pSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addComponent(searchBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 922, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(67, 67, 67)
                .addComponent(Name, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jLabel3)
                .addGap(48, 48, 48)
                .addComponent(Address, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(Register, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(jLabel5)
                .addGap(56, 56, 56)
                .addComponent(Male)
                .addGap(45, 45, 45)
                .addComponent(Female)
                .addGap(33, 33, 33)
                .addComponent(jLabel8)
                .addGap(18, 18, 18)
                .addComponent(ContactNo, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(Save, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(jLabel4)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Occupation, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Age, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addComponent(jLabel6)
                .addGap(27, 27, 27)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Edit, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Delete, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dashBoard, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(searchBTN, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(19, 19, 19)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 308, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(Name, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(Address, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Register, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(Male)
                    .addComponent(Female)
                    .addComponent(jLabel8)
                    .addComponent(ContactNo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Save, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(19, 19, 19)
                        .addComponent(jLabel4)
                        .addGap(19, 19, 19)
                        .addComponent(jLabel7))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(17, 17, 17)
                        .addComponent(Occupation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Age, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel6)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(Edit, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(Delete, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(dashBoard, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 999, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void AddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_AddressActionPerformed

    private void FemaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FemaleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_FemaleActionPerformed

    private void OccupationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OccupationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_OccupationActionPerformed

    private void ContactNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContactNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContactNoActionPerformed

    private void RegisterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterActionPerformed
        int row = jTable1.getSelectedRow();

        if (row >= 0) {
            // Retrieve data from the selected row
            String pID = model.getValueAt(row, 1).toString();
            String name = model.getValueAt(row, 2).toString();
            String age = model.getValueAt(row, 3).toString();
            String gender = model.getValueAt(row, 4).toString();
            String status = model.getValueAt(row, 5).toString();
            String occupation = model.getValueAt(row, 6).toString();
            String contact = model.getValueAt(row, 7).toString();
            String address = model.getValueAt(row, 8).toString();
            String complaint = model.getValueAt(row, 9).toString();

            // Create an instance of PatientManagementMaster and pass patient data
            PatientManagementMaster patientManagementMaster = new PatientManagementMaster(this, userName, userRole, 
                pID, name, age, gender, status, occupation, contact, address, complaint);

            // Show the PatientManagementMaster frame
            patientManagementMaster.setVisible(true);
            this.dispose(); // Close the PatientManagementJr frame
        } else {
            JOptionPane.showMessageDialog(this, "Please select a patient first.");
        }
    }//GEN-LAST:event_RegisterActionPerformed

    private void NameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_NameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_NameActionPerformed

    private void MaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MaleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MaleActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked

    }//GEN-LAST:event_jTable1MouseClicked

    private void DeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteActionPerformed
        int row = jTable1.getSelectedRow();
        if (row >= 0) {
            // Ensure the ID is correctly cast to an Integer
            Object idValue = model.getValueAt(row, 0); // Assuming the ID is in the first column
            int id;
            if (idValue instanceof Integer integer) {
                id = integer;
            } else {
                try {
                    id = Integer.parseInt(idValue.toString());
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(this, "Error: Invalid ID format.");
                    return;
                }
            }

            // Get the patient ID from the selected row
            String patientID = model.getValueAt(row, 1).toString();

            // Remove the row from the JTable
            model.removeRow(row);

            // Delete the record from the database
            deleteDataFromDatabase(id, patientID);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.");
        }
    }//GEN-LAST:event_DeleteActionPerformed

    private void SaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SaveActionPerformed
        // Retrieve input values
        String pID = IDGenerator.generateID();

        String name = Name.getText().trim();
        String age = Age.getValue().toString();
        String gender = Male.isSelected() ? "Male" : "Female";
        String maritalStatus = jComboBox1.getSelectedItem().toString(); // Get selected item from combo box
        String occupation = Occupation.getText().trim();
        String contactNumber = ContactNo.getText().trim();
        String address = Address.getText().trim();
        String complaint = Complaint.getText().trim();

        // Validate contact number
        if (!isValidContactNumber(contactNumber)) {
            return; // Exit the method if contact number is invalid
        }

        // Check if any input field is empty
        if (!areFieldsFilled(name, age, gender, maritalStatus, occupation, contactNumber, address, complaint)) {
            JOptionPane.showMessageDialog(this, "All fields must be filled out.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return; // Exit the method if any field is empty
        }

        if (selectedRow >= 0) {
            // Update existing row directly in JTable
            Object[] rowData = {
                model.getValueAt(selectedRow, 0), // ID
                model.getValueAt(selectedRow, 1), // Patient ID
                name,
                age,
                gender,
                maritalStatus,
                occupation,
                contactNumber,
                address,
                complaint
            };

            for (int i = 0; i < rowData.length; i++) {
                model.setValueAt(rowData[i], selectedRow, i);
            }

            // Update the database
            String query = "UPDATE tblpatientinfo SET name = ?, age = ?, gender = ?, maritalStatus = ?, occupation = ?, contactNumber = ?, address = ?, complaint = ? WHERE ID = ?";

            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setString(1, name);
                statement.setString(2, age);
                statement.setString(3, gender);
                statement.setString(4, maritalStatus);
                statement.setString(5, occupation);
                statement.setString(6, contactNumber);
                statement.setString(7, address);
                statement.setString(8, complaint);
                statement.setString(9, model.getValueAt(selectedRow, 0).toString()); // ID

                if (statement.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "Patient Information Updated", "Database Updated", JOptionPane.INFORMATION_MESSAGE);
                }
            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }

            selectedRow = -1; // Reset selection after update
        } else {
            // Add new row to JTable
            Object[] newRow = {
                model.getRowCount() + 1, 
                pID,
                name,
                age,
                gender,
                maritalStatus,
                occupation,
                contactNumber,
                address,
                complaint
            };

            model.addRow(newRow);

            PreparedStatement statement;
            String query;

            boolean found = false;
            int rowsAffected;

            try {        
                query = "SELECT * FROM tblpatientid";
                statement = connection.prepareStatement(query);
                ResultSet result = statement.executeQuery();

                while (result.next()) {

                    String reference = result.getString("name");

                    if (name.equalsIgnoreCase(reference)) {
                        pID = result.getString("patientID");
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    query = "INSERT INTO tblpatientid(patientID, name) VALUES (?, ?)";
                    statement = connection.prepareStatement(query);
                    statement.setString(1, pID);
                    statement.setString(2, name);
                    rowsAffected = statement.executeUpdate();
                    statement.close();
                }

            } catch (SQLException e){
                System.out.println("Error" + e.getMessage());
            }

            if (!name.isEmpty() && !contactNumber.isEmpty()) {
                query = "INSERT INTO tblpatientinfo (patientID, name, age, gender, maritalStatus, occupation, contactNumber, address, complaint) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

                try {
                    statement = connection.prepareStatement(query);
                    statement.setString(1, pID);
                    statement.setString(2, name);
                    statement.setString(3, age);
                    statement.setString(4, gender);
                    statement.setString(5, maritalStatus);
                    statement.setString(6, occupation);
                    statement.setString(7, contactNumber);
                    statement.setString(8, address);
                    statement.setString(9, complaint);

                    rowsAffected = statement.executeUpdate();

                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(null, "Patient Information Added", "Database Updated", JOptionPane.INFORMATION_MESSAGE);
                    }

                    getData();

                } catch (SQLException e) {
                    System.out.println("Error: " + e.getMessage());
                }
            }
        }

        // Clear fields after saving
        Name.setText("");
        Age.setValue(0);
        Male.setSelected(false);
        Female.setSelected(false);
        jComboBox1.setSelectedIndex(0);
        Occupation.setText("");
        ContactNo.setText("");
        Address.setText("");
        Complaint.setText("");
    }//GEN-LAST:event_SaveActionPerformed

    private void EditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EditActionPerformed
       
        selectedRow = jTable1.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a patient to edit.");
        return;
    }

    // Retrieve data from the selected row with null checks
    Object idObj = jTable1.getValueAt(selectedRow, 0);
    Object patientIdObj = jTable1.getValueAt(selectedRow, 1);
    Object nameObj = jTable1.getValueAt(selectedRow, 2);
    Object ageObj = jTable1.getValueAt(selectedRow, 3);
    Object genderObj = jTable1.getValueAt(selectedRow, 4);
    Object statusObj = jTable1.getValueAt(selectedRow, 5);
    Object occupationObj = jTable1.getValueAt(selectedRow, 6);
    Object contactNumberObj = jTable1.getValueAt(selectedRow, 7);
    Object addressObj = jTable1.getValueAt(selectedRow, 8);
    Object complaintObj = jTable1.getValueAt(selectedRow, 9);

    // Set default values to empty strings if null
    String id = (idObj == null) ? "" : String.valueOf(idObj);
    String patientId = (patientIdObj == null) ? "" : String.valueOf(patientIdObj);
    String name = (nameObj == null) ? "" : String.valueOf(nameObj);
    String age = (ageObj == null) ? "" : String.valueOf(ageObj);
    String gender = (genderObj == null) ? "" : String.valueOf(genderObj);
    String status = (statusObj == null) ? "" : String.valueOf(statusObj);
    String occupation = (occupationObj == null) ? "" : String.valueOf(occupationObj);
    String contactNumber = (contactNumberObj == null) ? "" : String.valueOf(contactNumberObj);
    String address = (addressObj == null) ? "" : String.valueOf(addressObj);
    String complaint = (complaintObj == null) ? "" : String.valueOf(complaintObj);

    // Populate text fields
    Name.setText(name);
    try {
        Age.setValue(age.isEmpty() ? 0 : Integer.valueOf(age));
    } catch (NumberFormatException e) {
        Age.setValue(0);
    }

    if (gender.equalsIgnoreCase("MALE")) {
        Male.setSelected(true);
    } else if (gender.equalsIgnoreCase("FEMALE")) {
        Female.setSelected(true);
    } else {
        genderGroup.clearSelection();
    }

    jComboBox1.setSelectedItem(status);
    Occupation.setText(occupation);
    ContactNo.setText(contactNumber);
    Address.setText(address);
    Complaint.setText(complaint);
    }//GEN-LAST:event_EditActionPerformed

    private void dashBoardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dashBoardActionPerformed
        // TODO add your handling code here:
        this.dispose();
        goToDashboard();

    }//GEN-LAST:event_dashBoardActionPerformed

    private void searchBTNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBTNActionPerformed
         String searchText = pSearch.getText().trim().toLowerCase();
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
    jTable1.setRowSorter(sorter);


    if (searchText.isEmpty()) {
        sorter.setRowFilter(null);
    } else {
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText, 2, 4));
    }

    model.fireTableDataChanged();
    }//GEN-LAST:event_searchBTNActionPerformed

    private void pSearchjTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pSearchjTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pSearchjTextField3ActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed


    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
    try {
        for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
            if ("Nimbus".equals(info.getName())) {
                javax.swing.UIManager.setLookAndFeel(info.getClassName());
                break;
            }
        }
    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
        java.util.logging.Logger.getLogger(PatientManagementJr.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
    }
        //</editor-fold>
        
    //</editor-fold>

    /* Create and display the form */
    java.awt.EventQueue.invokeLater(() -> {
        
        
    });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Address;
    private javax.swing.JSpinner Age;
    private javax.swing.JTextArea Complaint;
    private javax.swing.JTextField ContactNo;
    private javax.swing.JButton Delete;
    private javax.swing.JButton Edit;
    private javax.swing.JRadioButton Female;
    private javax.swing.JRadioButton Male;
    private javax.swing.JTextField Name;
    private javax.swing.JTextField Occupation;
    private javax.swing.JButton Register;
    private javax.swing.JButton Save;
    private javax.swing.JButton dashBoard;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField pSearch;
    private javax.swing.JButton searchBTN;
    // End of variables declaration//GEN-END:variables
}
